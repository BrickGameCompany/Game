let WictoryState = {
	create: function() {
		game.add.sprite(0,0,'background_menu');
		game.add.text(100,100,"Wygrałeś");
	}
};